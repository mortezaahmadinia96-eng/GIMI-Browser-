package com.gimi.browser;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView web;
    private EditText address;
    private LinearLayout home;
    private int bg = Color.rgb(8,9,24);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(12),dp(10),dp(12),dp(10));
        TextView mark = new TextView(this); mark.setText("G"); mark.setTextColor(Color.WHITE); mark.setTextSize(24); mark.setTypeface(Typeface.DEFAULT,Typeface.BOLD); mark.setGravity(Gravity.CENTER);
        GradientDrawable logo = new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(255,220,75),Color.rgb(174,103,255),Color.rgb(255,105,190),Color.rgb(94,218,255)}); logo.setCornerRadius(dp(15)); mark.setBackground(logo); top.addView(mark,new LinearLayout.LayoutParams(dp(44),dp(44)));
        TextView title = new TextView(this); title.setText("  GIMI"); title.setTextColor(Color.WHITE); title.setTextSize(23); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); top.addView(title);
        View gap = new View(this); top.addView(gap,new LinearLayout.LayoutParams(0,1,1));
        Button homeBtn = pill("⌂"); top.addView(homeBtn,new LinearLayout.LayoutParams(dp(46),dp(42))); homeBtn.setOnClickListener(v -> showHome());
        root.addView(top);
        LinearLayout search = new LinearLayout(this); search.setOrientation(LinearLayout.HORIZONTAL); search.setGravity(Gravity.CENTER_VERTICAL); search.setPadding(dp(12),dp(7),dp(12),dp(10));
        address = new EditText(this); address.setSingleLine(true); address.setTextColor(Color.WHITE); address.setHintTextColor(Color.rgb(165,172,205)); address.setHint("جست‌وجو یا واردکردن آدرس سایت"); address.setTextSize(14); address.setPadding(dp(14),0,dp(8),0); address.setImeOptions(EditorInfo.IME_ACTION_GO);
        GradientDrawable field = new GradientDrawable(); field.setColor(Color.rgb(25,29,55)); field.setCornerRadius(dp(18)); field.setStroke(dp(1),Color.rgb(89,83,140)); address.setBackground(field);
        search.addView(address,new LinearLayout.LayoutParams(0,dp(48),1)); Button go = pill("➜"); LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(48),dp(48)); gp.leftMargin=dp(8); search.addView(go,gp); go.setOnClickListener(v -> navigate()); address.setOnEditorActionListener((v,action,event)->{if(action==EditorInfo.IME_ACTION_GO || (event!=null && event.getKeyCode()==KeyEvent.KEYCODE_ENTER)){navigate();return true;}return false;}); root.addView(search);
        web = new WebView(this); web.setBackgroundColor(bg); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setLoadsImagesAutomatically(true); web.setWebViewClient(new WebViewClient(){@Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap favicon){address.setText(url);}}); web.setWebChromeClient(new WebChromeClient());
        home = buildHome(); root.addView(home,new LinearLayout.LayoutParams(-1,0,1)); root.addView(web,new LinearLayout.LayoutParams(-1,0,1)); web.setVisibility(View.GONE);
        LinearLayout bottom = new LinearLayout(this); bottom.setGravity(Gravity.CENTER); bottom.setPadding(dp(8),dp(5),dp(8),dp(8));
        Button back=pill("‹"); Button forward=pill("›"); Button reload=pill("↻"); Button tabs=pill("▢");
        for(Button b:new Button[]{back,forward,reload,tabs}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(42),1);p.setMargins(dp(4),0,dp(4),0);bottom.addView(b,p);}
        back.setOnClickListener(v->{if(web.getVisibility()==View.VISIBLE&&web.canGoBack())web.goBack();}); forward.setOnClickListener(v->{if(web.getVisibility()==View.VISIBLE&&web.canGoForward())web.goForward();}); reload.setOnClickListener(v->{if(web.getVisibility()==View.VISIBLE)web.reload();else showHome();}); tabs.setOnClickListener(v->showHome()); root.addView(bottom); setContentView(root);
    }
    private LinearLayout buildHome(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(20),dp(20),dp(12));
        TextView eyebrow=new TextView(this);eyebrow.setText("EXPLORE BEYOND  ✦");eyebrow.setTextColor(Color.rgb(126,210,255));eyebrow.setTextSize(12);eyebrow.setGravity(Gravity.CENTER);box.addView(eyebrow);
        TextView hero=new TextView(this);hero.setText("GIMI");hero.setTextColor(Color.WHITE);hero.setTextSize(44);hero.setTypeface(Typeface.DEFAULT,Typeface.BOLD);hero.setGravity(Gravity.CENTER);hero.setPadding(0,dp(6),0,0);box.addView(hero);
        TextView sub=new TextView(this);sub.setText("دنیای وب، با سبک خودت");sub.setTextColor(Color.rgb(192,190,224));sub.setTextSize(15);sub.setGravity(Gravity.CENTER);sub.setPadding(0,0,0,dp(25));box.addView(sub);
        TextView heading=new TextView(this);heading.setText("  دسترسی سریع");heading.setTextColor(Color.WHITE);heading.setTextSize(16);heading.setTypeface(null,Typeface.BOLD);box.addView(heading);
        String[][] items={{"⌕","جست‌وجو","#FFE15A"},{"🎮","بازی‌ها","#B88BFF"},{"♡","نشانک‌ها","#FF83CA"},{"◎","اکتشاف وب","#78DEFF"}};
        for(int row=0;row<2;row++){LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(90));lp.topMargin=dp(10);box.addView(line,lp);for(int col=0;col<2;col++){String[] it=items[row*2+col];TextView tile=new TextView(this);tile.setText(it[0]+"\n"+it[1]);tile.setTextColor(Color.WHITE);tile.setTextSize(15);tile.setGravity(Gravity.CENTER);GradientDrawable gd=new GradientDrawable();gd.setColor(Color.rgb(24,25,49));gd.setCornerRadius(dp(18));gd.setStroke(dp(1),Color.parseColor(it[2]));tile.setBackground(gd);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-1,1);tp.setMargins(dp(4),0,dp(4),0);line.addView(tile,tp);tile.setOnClickListener(v->{address.setText("https://www.google.com");navigate();});}}
        TextView foot=new TextView(this);foot.setText("زرد  •  بنفش  •  صورتی  •  آبی روشن");foot.setTextColor(Color.rgb(145,151,190));foot.setGravity(Gravity.CENTER);foot.setTextSize(12);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,dp(45));fp.topMargin=dp(10);box.addView(foot,fp);return box;
    }
    private Button pill(String text){Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setTextSize(18);b.setAllCaps(false);b.setPadding(0,0,0,0);GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(27,29,54));d.setCornerRadius(dp(15));d.setStroke(dp(1),Color.rgb(65,67,105));b.setBackground(d);return b;}
    private void navigate(){String q=address.getText().toString().trim();if(q.isEmpty())return;String url;if(q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*"))url=q;else if(q.contains(".")&&!q.contains(" "))url="https://"+q;else url="https://www.google.com/search?q="+android.net.Uri.encode(q);home.setVisibility(View.GONE);web.setVisibility(View.VISIBLE);web.loadUrl(url);((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);}
    private void showHome(){web.stopLoading();web.setVisibility(View.GONE);home.setVisibility(View.VISIBLE);address.setText("");}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    @Override public void onBackPressed(){if(web!=null&&web.getVisibility()==View.VISIBLE&&web.canGoBack())web.goBack();else showHome();}
}
